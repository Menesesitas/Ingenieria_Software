public class ObservadorEjemplo
{
    public static void main(String[] args) {
        Tienda tienda = new Tienda();
        Cliente cliente1 = new Cliente("Juan", "iPhone");
        Cliente cliente2 = new Cliente("Maria", "iPhone");
        tienda.agregarCliente(cliente1);
        tienda.agregarCliente(cliente2);

        // La tienda recibe un nuevo producto de iPhone y notifica a los clientes interesados
        tienda.setNuevoProducto("iPhone");
    }
}