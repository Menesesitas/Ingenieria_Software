import java.util.ArrayList;
import java.util.List;

// Sujeto observado
public class Tienda {
    private List<Cliente> clientes = new ArrayList<>();
    private String nuevoProducto;

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void eliminarCliente(Cliente cliente) {
        clientes.remove(cliente);
    }

    public void notificarClientes() {
        for (Cliente cliente : clientes) {
            cliente.actualizar(nuevoProducto);
        }
    }

    public void setNuevoProducto(String nuevoProducto) {
        this.nuevoProducto = nuevoProducto;
        notificarClientes();
    }
}